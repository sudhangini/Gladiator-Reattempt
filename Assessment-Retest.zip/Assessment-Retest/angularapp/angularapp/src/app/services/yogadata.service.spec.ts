import { TestBed } from '@angular/core/testing';

import { YogadataService } from './yogadata.service';

describe('YogadataService', () => {
  let service: YogadataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(YogadataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
