import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AppService } from '../app.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent {
  Login = new FormGroup(
    {
      email: new FormControl('', [Validators.required, Validators.email]),

      password: new FormControl('', [Validators.required])

    }

  )
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private appService: AppService) { }


  LoginForm() {
    if (this.Login.status == 'VALID') {
      this.appService.login(this.Login.controls.email.value, this.Login.controls.password.value).subscribe((result) => {
        if (result == true) {
          console.log(result);
          this.appService.getUserDetailByEmail(this.Login.controls.email.value ? this.Login.controls.email.value : '')
            .subscribe(data => {
              this.appService.setLoggedInUserDetails(data);
              this.router.navigate(['/yoga-dashboard']);
            })
        }
        else {
          Swal.fire("wrong credentials");
        }

      })

    }

    else {
      // alert("Username and password are required");
      Swal.fire("Username and password are required");
    }
    console.log(this.Login);
  }
  get email() {

    return this.Login.get('email')

  }

  get password() {

    return this.Login.get('password')

  }



}
