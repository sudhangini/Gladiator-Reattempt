import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { YogadataService } from 'src/app/services/yogadata.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  Candidate:FormGroup;
  constructor(private yogadata:YogadataService,private router:Router){
    this.Candidate=new FormGroup(
  {
              personId : new FormControl(''),
              personName: new FormControl('', [Validators.required]),

              personAddress:new FormControl('',[Validators.required]),
          
              personPhone: new FormControl('',[Validators.required, Validators.pattern('[0-9]{10}')]),
              personEmail: new FormControl('',[Validators.required, Validators.email]),   
              personExp: new FormControl('',[Validators.required, Validators.min(1), Validators.max(60)])
    }
      
    );
  }
  ngOnInit(){
   
  }
  saveCandidateData(){
    this.yogadata.savecandidate({...this.Candidate.value, personId:'CAN'+(Math.random() * 1000)}).subscribe((result)=>
    {
      console.log(result);
      this.router.navigate(['/yoga-dashboard/candidates' ]);
    })
  }

  
  get personName() {
    return this.Candidate.get('personName')
  }

  get personAddress() {
    return this.Candidate.get('personAddress')
  }

  get personPhone() {
    return this.Candidate.get('personPhone')
  }

  get personEmail() {
    return this.Candidate.get('personEmail')
  }

  get personExp() {
    return this.Candidate.get('personExp')
  }
}
