import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
// import { AppService } from 'src/app/app.service';
import { YogadataService } from 'src/app/services/yogadata.service';

@Component({
  selector: 'app-adminupdate',
  templateUrl: './adminupdate.component.html',
  styleUrls: ['./adminupdate.component.css']
})
export class AdminupdateComponent {
  @Input() canFormValue:any;
  @Output() getCandiates = new EventEmitter<any>();
  canForm: FormGroup = new FormGroup({
    personName: new FormControl('', [Validators.required]),

    personAddress:new FormControl('',[Validators.required]),

    personPhone: new FormControl('',[Validators.required, Validators.pattern('[0-9]{10}')]),
    personEmail: new FormControl('',[Validators.required, Validators.email]),   
    personExp: new FormControl('',[Validators.required, Validators.min(1), Validators.max(60)])
  }
    
  )

  constructor(private route: ActivatedRoute,
    private router: Router,
    private yogaService: YogadataService){
      
    }

    ngOnInit(){
      this.canForm = new FormGroup({
        personName: new FormControl(this.canFormValue.personName, [Validators.required]),
    
        personAddress:new FormControl(this.canFormValue.personAddress,[Validators.required]),
    
        personPhone: new FormControl(this.canFormValue.personPhone,[Validators.required, Validators.pattern('[0-9]{10}')]),
        personEmail: new FormControl(this.canFormValue.personEmail,[Validators.required, Validators.email]),   
        personExp: new FormControl(this.canFormValue.personExp,[Validators.required, Validators.min(1), Validators.max(60)])
      });
    }


    deletecandidate(){
  
     this.yogaService.deletecandidate(this.canFormValue.personId).subscribe((result)=>{
     // this.getcandidate();   
     this.getCandiates.emit(null);
     alert("deleted successfully");
    });
  }
  
  editcandidate(){
  
   this.yogaService.editcandidate({personId: this.canFormValue.personId, ...this.canForm.value}).subscribe((result)=>{
    //this.getcandidate();  
     this.getCandiates.emit(null); 
    alert("Details updated successfully");
  });
  }

  get personName() {
    return this.canForm.get('personName')
  }

  get personAddress() {
    return this.canForm.get('personAddress')
  }

  get personPhone() {
    return this.canForm.get('personPhone')
  }

  get personEmail() {
    return this.canForm.get('personEmail')
  }

  get personExp() {
    return this.canForm.get('personExp')
  }
  
}
