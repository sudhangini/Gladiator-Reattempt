import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { YogadataService } from 'src/app/services/yogadata.service';

@Component({
  selector: 'app-customeraddjob',
  templateUrl: './customeraddjob.component.html',
  styleUrls: ['./customeraddjob.component.css']
})
export class CustomeraddjobComponent {

  yoga=new FormGroup(
     {
            jobId : new FormControl('', Validators.required),
       jobDescription:new FormControl('', Validators.required),
       jobLocation:new FormControl('', Validators.required),
       fromDate:new FormControl('', Validators.required),
      toDate:new FormControl('', [Validators.required, ]),    
      wagePerDay:new FormControl('', [Validators.required, Validators.min(100), Validators.max(9000)])    
     }, 
);
  constructor(private yogadata:YogadataService,private router:Router){
   
  }
  ngOnInit(){
    this.yogadata.yogas().subscribe((data=>
      {
        console.log("data",data);
      }))
  }
  

  getYogaFormData(){
    this.yogadata.saveyoga(this.yoga.value).subscribe((result)=>
    {
      console.log(result);
      this.router.navigate(['/yoga-dashboard/openings' ]);
    })
  }

  dateLessThan(from: string, to: string) {
      

    return (yoga: FormGroup): {[key: string]: any} => {
     let f = yoga.controls[from];
     let t = yoga.controls[to];
     if (f.value > t.value) {
       return {
         dates: "Date from should be less than Date to"
       };
     }
     return {};
    }
  }

  get jobDescription() {
    return this.yoga.get('jobDescription')
  }

  get jobLocation() {
    return this.yoga.get('jobLocation')
  }

  get fromDate() {
    return this.yoga.get('fromDate')
  }

  get toDate() {
    return this.yoga.get('toDate')
  }

  get wagePerDay() {
    return this.yoga.get('wagePerDay')
  }
  

}


