package com.YogaTrainer.YogaProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.YogaTrainer.YogaProject.Model.AdminModel;

@Repository
public interface AdminModelRepo extends JpaRepository<AdminModel, String> {

}
