package com.YogaTrainer.YogaProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YogaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(YogaProjectApplication.class, args);
	}

}
